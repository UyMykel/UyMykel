/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bank_system;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
/**
 *
 * @author MJR BROTHERS
 */
public class Bank_System {
 
       private static double balance = 0;
         private static ArrayList<Double> deposits = new ArrayList<>();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //char[] Array = {'A','B','C','D','E'};
       Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Banking System Menu:");
            System.out.println("A. Deposit ");
            System.out.println("B. Withdraw ");
            System.out.println("C. Balance");
            System.out.println("D. View Deposits in Order");
            System.out.println("E. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.next().charAt(0);

            switch (choice) {
                case 'A':
                    depositMoney(scanner);
                    break;
                case 'B':
                    withdrawMoney(scanner);
                    break;
                case 'C':
                    checkBalance();
                    break;
                case 'D':
                    viewDepositsAscending();
                    break;
                case 'E':
                    System.out.println("Exiting the banking system. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void depositMoney(Scanner scanner) {
        System.out.print("Enter the amount to deposit: $");
        double amount = scanner.nextDouble();
        if (amount > 0) {
            balance += amount;
            deposits.add(amount);
            System.out.println("$" + amount + " deposited successfully.");
        } else { 
          System.out.println("Invalid deposit amount. Please enter a positive amount.");
        }
    }

    private static void withdrawMoney(Scanner scanner) {
        System.out.print("Enter the amount to withdraw: $");
        double amount = scanner.nextDouble();
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("$" + amount + " withdrawn successfully.");
        } else {
            System.out.println("Invalid amount or Insufficient balance.");
        }
    }

    private static void checkBalance() {
        System.out.println("Your current balance is: $" + balance);
        }

    private static void viewDepositsAscending() {
        if (deposits.isEmpty()) {
            System.out.println("No deposits have been made yet.");
        } else {
            Collections.sort(deposits);
            System.out.println("Deposits in ascending order: " + deposits);
        }
    }
} 
      
    

  

